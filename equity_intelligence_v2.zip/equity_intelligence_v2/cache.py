import sqlite3
import json
import hashlib
from datetime import datetime, timedelta
from config import DB_PATH, TTL, MARKET_OPEN, MARKET_CLOSE


def _conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    """Create tables on first run."""
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS cache (
                cache_key   TEXT PRIMARY KEY,
                layer       TEXT NOT NULL,
                value       TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                expires_at  TEXT NOT NULL,
                hit_count   INTEGER DEFAULT 0
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS budget (
                key_id      TEXT NOT NULL,
                model       TEXT NOT NULL,
                date        TEXT NOT NULL,
                req_count   INTEGER DEFAULT 0,
                token_count INTEGER DEFAULT 0,
                PRIMARY KEY (key_id, model, date)
            )
        """)
        c.execute("CREATE INDEX IF NOT EXISTS idx_expires ON cache(expires_at)")


# ─── TTL HELPERS ─────────────────────────────────────────────────────────────

def _is_market_hours():
    now = datetime.now().strftime("%H:%M")
    return MARKET_OPEN <= now <= MARKET_CLOSE


def _ttl_hours(layer: str) -> int:
    hours = TTL[layer]
    if layer == "equity" and _is_market_hours():
        return 1
    return hours


def _expires(layer: str) -> str:
    return (datetime.now() + timedelta(hours=_ttl_hours(layer))).isoformat()


# ─── KEY BUILDERS ─────────────────────────────────────────────────────────────

def article_key(title: str, description: str) -> str:
    text = (title + description).lower().strip()
    return "article:" + hashlib.sha256(text.encode()).hexdigest()[:16]


def sector_key(sector: str) -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    return f"sector:{sector}:{date}"


def equity_key(symbol: str) -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    hour = datetime.now().strftime("%H")
    return f"equity:{symbol}:{date}:{hour}"


def user_key(user_id: str, symbol: str) -> str:
    date = datetime.now().strftime("%Y-%m-%d")
    return f"user:{user_id}:{symbol}:{date}"


# ─── CORE OPERATIONS ─────────────────────────────────────────────────────────

def get(key: str):
    """Return cached value or None if missing/expired."""
    with _conn() as c:
        row = c.execute(
            "SELECT value FROM cache WHERE cache_key=? AND expires_at>?",
            (key, datetime.now().isoformat())
        ).fetchone()
        if row:
            c.execute(
                "UPDATE cache SET hit_count=hit_count+1 WHERE cache_key=?",
                (key,)
            )
            return json.loads(row["value"])
    return None


def set(key: str, layer: str, value: dict):
    """Store value with correct TTL for the layer."""
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO cache
            (cache_key, layer, value, created_at, expires_at, hit_count)
            VALUES (?, ?, ?, ?, ?, 0)
        """, (
            key,
            layer,
            json.dumps(value),
            datetime.now().isoformat(),
            _expires(layer),
        ))


def delete(key: str):
    """Invalidate a cache entry (breaking news)."""
    with _conn() as c:
        c.execute("DELETE FROM cache WHERE cache_key=?", (key,))


def purge_expired():
    """Delete all expired rows — run once at startup."""
    with _conn() as c:
        deleted = c.execute(
            "DELETE FROM cache WHERE expires_at<?",
            (datetime.now().isoformat(),)
        ).rowcount
    print(f"[cache] purged {deleted} expired rows")


def stats():
    """Print cache hit summary."""
    with _conn() as c:
        rows = c.execute(
            "SELECT layer, COUNT(*) as n, SUM(hit_count) as hits FROM cache GROUP BY layer"
        ).fetchall()
    for r in rows:
        print(f"[cache] layer={r['layer']}  entries={r['n']}  total_hits={r['hits']}")
