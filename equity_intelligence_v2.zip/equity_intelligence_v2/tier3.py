import json
from groq import Groq
from config import TIER3_BATCH_SIZE, QUALITY_THRESHOLD
import cache
import budget as bgt
import router

SYSTEM_PROMPT = """You are a senior equity analyst.
Analyze how each news article affects the given stock.
Respond ONLY with a valid JSON array, no other text.
Format:
[{
  "id": 0,
  "impact": "HIGH",
  "direction": "BULLISH",
  "confidence": "HIGH",
  "cause": "one sentence explaining the mechanism",
  "horizon": "IMMEDIATE"
}]
impact: HIGH / MEDIUM / LOW
direction: BULLISH / BEARISH / NEUTRAL
confidence: HIGH / MEDIUM / LOW
horizon: IMMEDIATE / SHORT_TERM / LONG_TERM"""


def _build_prompt(articles: list[dict], equity: dict) -> str:
    profile = (
        f"Stock: {equity['symbol']} ({equity.get('name', '')}) | "
        f"Sector: {equity['sector']} | "
        f"Revenue: {equity.get('revenue_exposure', 'N/A')} | "
        f"Risks: {', '.join(equity.get('risks', []))}"
    )
    items = "\n".join(
        f"{i}. [{a.get('type', '')} score={a.get('score', '?')}] "
        f"{a['title']} — {a.get('description', '')[:120]}"
        for i, a in enumerate(articles)
    )
    return f"{profile}\n\nAnalyze impact on {equity['symbol']}:\n{items}"


def _parse_analysis(text: str, count: int) -> list[dict]:
    """Parse LLM JSON response safely."""
    try:
        text = text.strip().strip("```json").strip("```").strip()
        results = json.loads(text)
        if isinstance(results, list) and len(results) == count:
            return results
    except Exception:
        pass
    print(f"[tier3] WARNING: failed to parse analysis, using fallback")
    return [
        {
            "id": i, "impact": "LOW", "direction": "NEUTRAL",
            "confidence": "LOW", "cause": "parse error", "horizon": "SHORT_TERM"
        }
        for i in range(count)
    ]


def _analyze_batch(articles: list[dict], equity: dict) -> list[dict]:
    """Analyze one batch of up to TIER3_BATCH_SIZE articles."""
    # use 70B for high-score direct articles, 8B for rest
    max_score = max(a.get("score", 0) for a in articles)
    est_tokens = 800

    api_key, model = router.get_key(
        tier=3,
        score=max_score,
        est_tokens=est_tokens
    )
    client = Groq(api_key=api_key)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": _build_prompt(articles, equity)},
        ],
        temperature=0.1,
        max_tokens=600,
    )

    tokens_used = response.usage.total_tokens
    key_id = "key_a" if api_key == router.GROQ_KEYS["key_a"] else "key_b"
    bgt.record(key_id, model, tokens_used)
    print(f"[tier3] used {model} ({tokens_used} tokens)")

    text    = response.choices[0].message.content
    results = _parse_analysis(text, len(articles))
    return results


# ─── MAIN ENTRY ───────────────────────────────────────────────────────────────

def run(articles: list[dict], equity: dict) -> list[dict]:
    """
    Deep analysis for all articles that passed Tier 2.
    Returns enriched articles with impact/direction/cause/horizon.
    Uses SQLite cache — sector/macro articles analyzed only once.
    """
    to_analyze    = []
    cached_results = []

    for a in articles:
        # company-specific articles always get fresh analysis
        if a.get("type") == "COMPANY_SPECIFIC":
            to_analyze.append(a)
            continue

        # shared articles: cache by article hash + sector
        key = "t3:" + cache.sector_key(equity["sector"]) + ":" + a["hash"]
        cached = cache.get(key)
        if cached:
            a.update(cached)
            cached_results.append(a)
        else:
            to_analyze.append(a)

    print(f"[tier3] {len(cached_results)} cache hits, {len(to_analyze)} to analyze")

    analyzed = []
    for i in range(0, len(to_analyze), TIER3_BATCH_SIZE):
        batch   = to_analyze[i : i + TIER3_BATCH_SIZE]
        results = _analyze_batch(batch, equity)

        for article, result in zip(batch, results):
            article.update({
                "impact":     result.get("impact",     "LOW"),
                "direction":  result.get("direction",  "NEUTRAL"),
                "confidence": result.get("confidence", "LOW"),
                "cause":      result.get("cause",      ""),
                "horizon":    result.get("horizon",    "SHORT_TERM"),
            })
            # cache shared articles
            if article.get("type") != "COMPANY_SPECIFIC":
                key = "t3:" + cache.sector_key(equity["sector"]) + ":" + article["hash"]
                cache.set(key, "sector", {
                    "impact":     article["impact"],
                    "direction":  article["direction"],
                    "confidence": article["confidence"],
                    "cause":      article["cause"],
                    "horizon":    article["horizon"],
                })
            analyzed.append(article)

    all_results = cached_results + analyzed

    # sort by impact priority
    impact_order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    all_results.sort(key=lambda x: impact_order.get(x.get("impact", "LOW"), 2))

    return all_results
