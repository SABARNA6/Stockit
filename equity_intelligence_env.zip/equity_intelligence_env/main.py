import json
import os
from config import EQUITIES_PATH, KEYWORDS_PATH

import cache
import budget
import pipeline


def load_equities() -> list[dict]:
    with open(EQUITIES_PATH) as f:
        return json.load(f)


def load_articles() -> list[dict]:
    """
    Replace this with your real news feed.
    For now returns sample articles for testing.
    """
    return [
        {
            "title": "TCS wins $300M deal with UK retailer",
            "description": "Tata Consultancy Services announced a major 5-year digital transformation contract with a leading UK retail group worth $300 million."
        },
        {
            "title": "US IT spending cuts expected in FY25",
            "description": "Major US corporations are planning to reduce IT outsourcing budgets by 8-12% amid economic uncertainty and AI automation adoption."
        },
        {
            "title": "RBI holds repo rate at 6.5%",
            "description": "The Reserve Bank of India kept the repo rate unchanged at 6.5% in its latest monetary policy committee meeting."
        },
        {
            "title": "INR weakens to 84.5 against USD",
            "description": "The Indian rupee fell to 84.5 against the US dollar amid FII outflows and global risk-off sentiment."
        },
        {
            "title": "Infosys cuts FY25 revenue guidance",
            "description": "Infosys revised its FY25 revenue growth guidance downward, citing weak demand from banking and financial services clients in North America."
        },
        {
            "title": "H1-B visa rejections rise 30%",
            "description": "US immigration authorities have increased H1-B visa rejection rates for Indian IT professionals by 30% compared to last year."
        },
        {
            "title": "Crude oil hits $100 per barrel",
            "description": "Global crude oil prices surged past $100 per barrel on supply concerns from the Middle East."
        },
        {
            "title": "India GDP revised upward to 7.2%",
            "description": "India's GDP growth forecast was revised upward to 7.2% by the IMF citing strong domestic consumption."
        },
        {
            "title": "Wipro announces share buyback",
            "description": "Wipro's board approved a share buyback program worth Rs 11,000 crore at a premium to market price."
        },
        {
            "title": "US Federal Reserve raises rates by 25bps",
            "description": "The US Fed increased interest rates by 25 basis points, signaling continued hawkish stance to control inflation."
        },
    ]


def print_results(result: dict):
    print(f"\n{'─'*60}")
    print(f"  EQUITY   : {result.get('symbol')}")
    print(f"  DIRECTION: {result.get('overall_direction')}")
    print(f"  SENTIMENT: {result.get('sentiment_score')} / 10")
    print(f"  ARTICLES : {result.get('articles_analyzed')} analyzed")
    print(f"  STATUS   : {result.get('cache_status')}")
    print(f"{'─'*60}")

    for r in result.get("results", []):
        print(
            f"  [{r.get('impact','?'):6}] "
            f"[{r.get('direction','?'):7}] "
            f"{r.get('title','')[:50]:<50}  "
            f"{r.get('cause','')[:60]}"
        )
    print()


def main():
    # ── setup ────────────────────────────────────────────────────────
    os.makedirs("db",   exist_ok=True)
    os.makedirs("data", exist_ok=True)
    cache.init()
    cache.purge_expired()

    # ── load data ────────────────────────────────────────────────────
    equities = load_equities()
    articles = load_articles()   # swap with real feed

    print(f"\n[main] {len(equities)} equities | {len(articles)} articles")
    budget.summary()

    # ── sort: process NIFTY50 first to warm sector cache ─────────────
    equities.sort(key=lambda e: (e.get("priority", 99), e["symbol"]))

    # ── run pipeline for each equity ─────────────────────────────────
    all_results = []
    for equity in equities:
        try:
            result = pipeline.run(articles, equity)
            all_results.append(result)
            print_results(result)
        except RuntimeError as e:
            print(f"\n[main] STOPPING: {e}")
            break
        except Exception as e:
            print(f"[main] ERROR on {equity['symbol']}: {e}")
            continue

    # ── final summary ─────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"[main] Completed {len(all_results)} equities")
    budget.summary()
    cache.stats()


if __name__ == "__main__":
    main()
